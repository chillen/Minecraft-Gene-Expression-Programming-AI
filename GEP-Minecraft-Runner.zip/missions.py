mission_files   = [ ['./wall0.xml', './lava0.xml'],
                    ['./wall1.xml', './lava1.xml'],
                    ['./wall2.xml', './lava2.xml']]